package ar.edu.unlp.info.oo1.ejercicio4;

public interface Figura {
    double getArea();
    double getPerimetro();
}
